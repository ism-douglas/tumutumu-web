<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbartopleft = array(
		array(
			'path' => 'assignments', 
			'label' => 'Assignments', 
			'icon' => ''
		),
		
		array(
			'path' => 'notes', 
			'label' => 'Notes', 
			'icon' => ''
		),
		
		array(
			'path' => 'past_papers', 
			'label' => 'Past Papers', 
			'icon' => ''
		)
	);
		
	
	
}